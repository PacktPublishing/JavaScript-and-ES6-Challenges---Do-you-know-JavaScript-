/* CHALLENGE 3 - Let

Change code to match output.
*/

"use strict";

var i = 10;

for (var i = 0; i < 5; i++) {
  // some stuff
  console.log(i);
}

console.log(i);
// BEFORE: 5
// AFTER: 10
