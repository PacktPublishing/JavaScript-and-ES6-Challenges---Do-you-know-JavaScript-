/* CHALLENGE 16 - Swap values of the two variables

Swap values of the a and b.
Don't use for this any new variable.
*/

"use strict";

var a = "first";
var b = "second";

// Write code here

console.log(a, b);
// second first
